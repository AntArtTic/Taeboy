﻿namespace CopyGuru_v2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_browse = new System.Windows.Forms.Button();
            this.btn_start_stop = new System.Windows.Forms.Button();
            this.txtbox_sourcePath = new System.Windows.Forms.TextBox();
            this.txtbox_targetPath = new System.Windows.Forms.TextBox();
            this.btn_target = new System.Windows.Forms.Button();
            this.chbox_delete = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.chbox_onePlace = new System.Windows.Forms.CheckBox();
            this.chbox_copyOneType = new System.Windows.Forms.CheckBox();
            this.txtbox_type = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.copyOnlyTop_chbox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_browse
            // 
            this.btn_browse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_browse.Location = new System.Drawing.Point(467, 29);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(75, 23);
            this.btn_browse.TabIndex = 0;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = true;
            this.btn_browse.Click += new System.EventHandler(this.Btn_browse_Click);
            // 
            // btn_start_stop
            // 
            this.btn_start_stop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_start_stop.BackColor = System.Drawing.Color.Peru;
            this.btn_start_stop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_start_stop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_start_stop.Location = new System.Drawing.Point(441, 151);
            this.btn_start_stop.Name = "btn_start_stop";
            this.btn_start_stop.Size = new System.Drawing.Size(101, 40);
            this.btn_start_stop.TabIndex = 1;
            this.btn_start_stop.Text = "Start";
            this.btn_start_stop.UseVisualStyleBackColor = false;
            this.btn_start_stop.Click += new System.EventHandler(this.Btn_start_stop_Click);
            // 
            // txtbox_sourcePath
            // 
            this.txtbox_sourcePath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbox_sourcePath.BackColor = System.Drawing.Color.FloralWhite;
            this.txtbox_sourcePath.Location = new System.Drawing.Point(27, 29);
            this.txtbox_sourcePath.Multiline = true;
            this.txtbox_sourcePath.Name = "txtbox_sourcePath";
            this.txtbox_sourcePath.ReadOnly = true;
            this.txtbox_sourcePath.Size = new System.Drawing.Size(434, 23);
            this.txtbox_sourcePath.TabIndex = 2;
            // 
            // txtbox_targetPath
            // 
            this.txtbox_targetPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtbox_targetPath.BackColor = System.Drawing.Color.FloralWhite;
            this.txtbox_targetPath.Location = new System.Drawing.Point(27, 78);
            this.txtbox_targetPath.Multiline = true;
            this.txtbox_targetPath.Name = "txtbox_targetPath";
            this.txtbox_targetPath.ReadOnly = true;
            this.txtbox_targetPath.Size = new System.Drawing.Size(434, 23);
            this.txtbox_targetPath.TabIndex = 4;
            // 
            // btn_target
            // 
            this.btn_target.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_target.Location = new System.Drawing.Point(467, 78);
            this.btn_target.Name = "btn_target";
            this.btn_target.Size = new System.Drawing.Size(75, 23);
            this.btn_target.TabIndex = 3;
            this.btn_target.Text = "Browse";
            this.btn_target.UseVisualStyleBackColor = true;
            this.btn_target.Click += new System.EventHandler(this.Btn_target_Click);
            // 
            // chbox_delete
            // 
            this.chbox_delete.AutoSize = true;
            this.chbox_delete.BackColor = System.Drawing.Color.FloralWhite;
            this.chbox_delete.Location = new System.Drawing.Point(27, 124);
            this.chbox_delete.Name = "chbox_delete";
            this.chbox_delete.Size = new System.Drawing.Size(211, 17);
            this.chbox_delete.TabIndex = 5;
            this.chbox_delete.Text = "Delete source file after successful copy";
            this.chbox_delete.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Source";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Target";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "images.png");
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDown1.BackColor = System.Drawing.Color.FloralWhite;
            this.numericUpDown1.Location = new System.Drawing.Point(444, 123);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(72, 20);
            this.numericUpDown1.TabIndex = 8;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(522, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "ms";
            // 
            // chbox_onePlace
            // 
            this.chbox_onePlace.AutoSize = true;
            this.chbox_onePlace.BackColor = System.Drawing.Color.FloralWhite;
            this.chbox_onePlace.Location = new System.Drawing.Point(27, 147);
            this.chbox_onePlace.Name = "chbox_onePlace";
            this.chbox_onePlace.Size = new System.Drawing.Size(160, 17);
            this.chbox_onePlace.TabIndex = 10;
            this.chbox_onePlace.Text = "Copy without folder structure";
            this.chbox_onePlace.UseVisualStyleBackColor = false;
            // 
            // chbox_copyOneType
            // 
            this.chbox_copyOneType.AutoSize = true;
            this.chbox_copyOneType.BackColor = System.Drawing.Color.FloralWhite;
            this.chbox_copyOneType.Location = new System.Drawing.Point(27, 170);
            this.chbox_copyOneType.Name = "chbox_copyOneType";
            this.chbox_copyOneType.Size = new System.Drawing.Size(116, 17);
            this.chbox_copyOneType.TabIndex = 11;
            this.chbox_copyOneType.Text = "Copy only one type";
            this.chbox_copyOneType.UseVisualStyleBackColor = false;
            // 
            // txtbox_type
            // 
            this.txtbox_type.BackColor = System.Drawing.Color.FloralWhite;
            this.txtbox_type.Location = new System.Drawing.Point(185, 170);
            this.txtbox_type.Name = "txtbox_type";
            this.txtbox_type.Size = new System.Drawing.Size(53, 20);
            this.txtbox_type.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(160, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "\".{                }\"";
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(353, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Copy pause time";
            // 
            // copyOnlyTop_chbox
            // 
            this.copyOnlyTop_chbox.AutoSize = true;
            this.copyOnlyTop_chbox.BackColor = System.Drawing.Color.FloralWhite;
            this.copyOnlyTop_chbox.Location = new System.Drawing.Point(27, 193);
            this.copyOnlyTop_chbox.Name = "copyOnlyTop_chbox";
            this.copyOnlyTop_chbox.Size = new System.Drawing.Size(162, 17);
            this.copyOnlyTop_chbox.TabIndex = 15;
            this.copyOnlyTop_chbox.Text = "Copy only Top level directory";
            this.copyOnlyTop_chbox.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 220);
            this.Controls.Add(this.copyOnlyTop_chbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtbox_type);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chbox_copyOneType);
            this.Controls.Add(this.chbox_onePlace);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chbox_delete);
            this.Controls.Add(this.txtbox_targetPath);
            this.Controls.Add(this.btn_target);
            this.Controls.Add(this.txtbox_sourcePath);
            this.Controls.Add(this.btn_start_stop);
            this.Controls.Add(this.btn_browse);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CopyGuru v2";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.Button btn_start_stop;
        private System.Windows.Forms.TextBox txtbox_sourcePath;
        private System.Windows.Forms.TextBox txtbox_targetPath;
        private System.Windows.Forms.Button btn_target;
        private System.Windows.Forms.CheckBox chbox_delete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chbox_onePlace;
        private System.Windows.Forms.CheckBox chbox_copyOneType;
        private System.Windows.Forms.TextBox txtbox_type;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox copyOnlyTop_chbox;
    }
}

